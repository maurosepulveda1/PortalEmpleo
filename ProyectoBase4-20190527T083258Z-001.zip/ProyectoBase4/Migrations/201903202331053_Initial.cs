namespace ProyectoBase4.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.AspNetUsers", "Rut", c => c.Int(nullable: false));
            AddColumn("dbo.AspNetUsers", "Nombres", c => c.String());
            AddColumn("dbo.AspNetUsers", "Apellidos", c => c.String());
            AddColumn("dbo.AspNetUsers", "FechaNacimiento", c => c.DateTime(nullable: false));
            AddColumn("dbo.AspNetUsers", "Telefono", c => c.Int(nullable: false));
            AddColumn("dbo.AspNetUsers", "Direccion", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.AspNetUsers", "Direccion");
            DropColumn("dbo.AspNetUsers", "Telefono");
            DropColumn("dbo.AspNetUsers", "FechaNacimiento");
            DropColumn("dbo.AspNetUsers", "Apellidos");
            DropColumn("dbo.AspNetUsers", "Nombres");
            DropColumn("dbo.AspNetUsers", "Rut");
        }
    }
}
