﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using IdentitySample.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using ProyectoBase4.Models;

namespace ProyectoBase4.Controllers
{
    public class VoluntariadoPostulanteController : Controller
    {
        private EntitiesPortal db = new EntitiesPortal();

        public ActionResult Index()
        {
            var voluntariadoPostulante = db.VoluntariadoPostulante.Include(v => v.AspNetUsers).Include(v => v.Voluntariado);
            if (Request.IsAuthenticated)
            {
                ViewBag.uservalueemail = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Email;
            }
            return View(voluntariadoPostulante.ToList().OrderByDescending(x => x.VolPostFecha));
        }

        public ActionResult PostulantesDeVoluntariado(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var vol_postulantes = db.VoluntariadoPostulante.Include(o => o.AspNetUsers).Where(o => o.VolPost_Vol_ID == id);

            return View(vol_postulantes);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VoluntariadoPostulante voluntariadoPostulante = db.VoluntariadoPostulante.Find(id);
            if (voluntariadoPostulante == null)
            {
                return HttpNotFound();
            }
            return View(voluntariadoPostulante);
        }

        public ActionResult Detalles1(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Voluntariado voluntariado = db.Voluntariado.Find(id);
            if (voluntariado == null)
            {
                return HttpNotFound();
            }
            return this.RedirectToAction("Details", "Voluntariado", new { id = voluntariado.Vol_ID });
        }

        public ActionResult Create()
        {
            ViewBag.VolPostUsr_ID = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Email;
            ViewBag.VolPost_Vol_ID = new SelectList(db.Voluntariado, "Vol_ID", "Vol_Titulo");

            var userID = User.Identity.GetUserId();

            var lista2 = (from u in db.Voluntariado
                          from a in db.DatosUsuario
                          where u.Vol_Edu == a.Educ_Sup
                          where u.Vol_Mov == a.Mov_Red
                          where u.Vol_Jornada == a.Jorn_Comp
                          where u.Vol_Estado == a.Tipo_trabajo
                          where a.DatosUser_ID == userID
                          orderby u.Vol_FechaIn descending
                          select u);

            ViewBag.ListaCondicion = lista2.ToList();

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "VolPost_ID,VolPost_Vol_ID,VolPostUsr_ID,VolPostFecha,VolPost_Estado")] VoluntariadoPostulante voluntariadoPostulante)
        {
            if (ModelState.IsValid)
            {
                db.VoluntariadoPostulante.Add(voluntariadoPostulante);
                var Datetimenow = DateTime.Now;
                voluntariadoPostulante.VolPostFecha = new DateTime(Datetimenow.Year, Datetimenow.Month, Datetimenow.Day, Datetimenow.Hour, Datetimenow.Minute, 0);
                voluntariadoPostulante.VolPostUsr_ID = HttpContext.User.Identity.GetUserId();
                db.SaveChanges();
                return RedirectToAction("Success");
            }

            ViewBag.VolPostUsr_ID = new SelectList(db.AspNetUsers, "Id", "Email", voluntariadoPostulante.VolPostUsr_ID);
            ViewBag.VolPost_Vol_ID = new SelectList(db.Voluntariado, "Vol_ID", "Vol_Titulo", voluntariadoPostulante.VolPost_Vol_ID);
            ViewBag.VolPost_Estado = new SelectList(db.EstadoPost, "EstadoPost_ID", "EstadoPost_Nombre", voluntariadoPostulante.VolPost_Estado);
            return View(voluntariadoPostulante);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VoluntariadoPostulante voluntariadoPostulante = db.VoluntariadoPostulante.Find(id);
            if (voluntariadoPostulante == null)
            {
                return HttpNotFound();
            }
            ViewBag.VolPostUsr_ID = new SelectList(db.AspNetUsers, "Id", "Email", voluntariadoPostulante.VolPostUsr_ID);
            ViewBag.VolPost_Vol_ID = new SelectList(db.Voluntariado, "Vol_ID", "Vol_Titulo", voluntariadoPostulante.VolPost_Vol_ID);
            ViewBag.VolPost_Estado = new SelectList(db.EstadoPost, "EstadoPost_ID", "EstadoPost_Nombre", voluntariadoPostulante.VolPost_Estado);
            return View(voluntariadoPostulante);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "VolPost_ID,VolPost_Vol_ID,VolPostUsr_ID,VolPostFecha,VolPost_Estado")] VoluntariadoPostulante voluntariadoPostulante)
        {
            if (ModelState.IsValid)
            {
                db.Entry(voluntariadoPostulante).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Success2");
            }
            ViewBag.VolPostUsr_ID = new SelectList(db.AspNetUsers, "Id", "Email", voluntariadoPostulante.VolPostUsr_ID);
            ViewBag.VolPost_Vol_ID = new SelectList(db.Voluntariado, "Vol_ID", "Vol_Titulo", voluntariadoPostulante.VolPost_Vol_ID);
            ViewBag.VolPost_Estado = new SelectList(db.EstadoPost, "EstadoPost_ID", "EstadoPost_Nombre", voluntariadoPostulante.VolPost_Estado);
            return View(voluntariadoPostulante);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VoluntariadoPostulante voluntariadoPostulante = db.VoluntariadoPostulante.Find(id);
            if (voluntariadoPostulante == null)
            {
                return HttpNotFound();
            }
            return View(voluntariadoPostulante);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            VoluntariadoPostulante voluntariadoPostulante = db.VoluntariadoPostulante.Find(id);
            db.VoluntariadoPostulante.Remove(voluntariadoPostulante);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Success()
        {
            return View();
        }
        public ActionResult Success2()
        {
            return View();
        }
        
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
