﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProyectoBase4.Models;

namespace ProyectoBase4.Controllers
{
    public class TipoTrabajoController : Controller
    {
        private EntitiesPortal db = new EntitiesPortal();

        // GET: TipoTrabajo
        public ActionResult Index()
        {
            return View(db.TipoTrabajo.ToList());
        }

        // GET: TipoTrabajo/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TipoTrabajo tipoTrabajo = db.TipoTrabajo.Find(id);
            if (tipoTrabajo == null)
            {
                return HttpNotFound();
            }
            return View(tipoTrabajo);
        }

        // GET: TipoTrabajo/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: TipoTrabajo/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "TipoTrabajo_ID,TipoTrabajo_Nombre")] TipoTrabajo tipoTrabajo)
        {
            if (ModelState.IsValid)
            {
                db.TipoTrabajo.Add(tipoTrabajo);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tipoTrabajo);
        }

        // GET: TipoTrabajo/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TipoTrabajo tipoTrabajo = db.TipoTrabajo.Find(id);
            if (tipoTrabajo == null)
            {
                return HttpNotFound();
            }
            return View(tipoTrabajo);
        }

        // POST: TipoTrabajo/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "TipoTrabajo_ID,TipoTrabajo_Nombre")] TipoTrabajo tipoTrabajo)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tipoTrabajo).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tipoTrabajo);
        }

        // GET: TipoTrabajo/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TipoTrabajo tipoTrabajo = db.TipoTrabajo.Find(id);
            if (tipoTrabajo == null)
            {
                return HttpNotFound();
            }
            return View(tipoTrabajo);
        }

        // POST: TipoTrabajo/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            TipoTrabajo tipoTrabajo = db.TipoTrabajo.Find(id);
            db.TipoTrabajo.Remove(tipoTrabajo);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
