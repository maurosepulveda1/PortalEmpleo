﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using IdentitySample.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using ProyectoBase4.Models;

namespace ProyectoBase4.Controllers
{
    public class DatosUsuarioController : Controller
    {
        private EntitiesPortal db = new EntitiesPortal();

        // GET: DatosUsuario
        public ActionResult Index()
        {
            var datosUsuario = db.DatosUsuario.Include(d => d.AspNetUsers).Include(d => d.Nacionalidad1).Include(d => d.TipoTrabajo);
            return View(datosUsuario.ToList());
        }

        // GET: DatosUsuario/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DatosUsuario datosUsuario = db.DatosUsuario.Find(id);
            if (datosUsuario == null)
            {
                return HttpNotFound();
            }
            return View(datosUsuario);
        }

        // GET: DatosUsuario/Create
        public ActionResult Create()
        {
            ViewBag.DatosUser_ID = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Email;
            ViewBag.Nacionalidad = new SelectList(db.Nacionalidad, "Nacionaldad_ID", "Nacionalidad_Nombre");
            ViewBag.Tipo_trabajo = new SelectList(db.TipoTrabajo, "TipoTrabajo_ID", "TipoTrabajo_Nombre");
            ViewBag.Educ_Sup = new SelectList(db.Educacion, "Edu_ID", "Edu_Nombre");
            ViewBag.Jorn_Comp = new SelectList(db.Jornada_Compl, "Jornada_ID", "Jornada_Nombre");
            ViewBag.Mov_Red = new SelectList(db.Movilidad, "Mov_ID", "Mov_Nombre");
            return View();
        }

 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "DatosUser_ID,Educ_Sup,Jorn_Comp,Mov_Red,Tipo_trabajo,Profesion,Exper_lab,Habi_des,Resumen_cv,Nacionalidad")] DatosUsuario datosUsuario)
        {
            if (ModelState.IsValid)
            {
                db.DatosUsuario.Add(datosUsuario);
                datosUsuario.DatosUser_ID = HttpContext.User.Identity.GetUserId();
                db.SaveChanges();
                return RedirectToAction("Index");

            }

            ViewBag.DatosUser_ID = new SelectList(db.AspNetUsers, "Id", "Email", datosUsuario.DatosUser_ID);
            ViewBag.Nacionalidad = new SelectList(db.Nacionalidad, "Nacionaldad_ID", "Nacionalidad_Nombre", datosUsuario.Nacionalidad);
            ViewBag.Tipo_trabajo = new SelectList(db.TipoTrabajo, "TipoTrabajo_ID", "TipoTrabajo_Nombre", datosUsuario.Tipo_trabajo);
            ViewBag.Educ_Sup = new SelectList(db.Educacion, "Edu_ID", "Edu_Nombre", datosUsuario.Educ_Sup);
            ViewBag.Jorn_Comp = new SelectList(db.Jornada_Compl, "Jornada_ID", "Jornada_Nombre", datosUsuario.Jorn_Comp);
            ViewBag.Mov_Red = new SelectList(db.Movilidad, "Mov_ID", "Mov_Nombre", datosUsuario.Mov_Red);
            return View(datosUsuario);
        }

        // GET: DatosUsuario/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DatosUsuario datosUsuario = db.DatosUsuario.Find(id);
            if (datosUsuario == null)
            {
                return HttpNotFound();
            }
            ViewBag.DatosUser_ID = new SelectList(db.AspNetUsers, "Id", "Email", datosUsuario.DatosUser_ID);
            ViewBag.Nacionalidad = new SelectList(db.Nacionalidad, "Nacionaldad_ID", "Nacionalidad_Nombre", datosUsuario.Nacionalidad);
            ViewBag.Tipo_trabajo = new SelectList(db.TipoTrabajo, "TipoTrabajo_ID", "TipoTrabajo_Nombre", datosUsuario.Tipo_trabajo);
            ViewBag.Educ_Sup = new SelectList(db.Educacion, "Edu_ID", "Edu_Nombre", datosUsuario.Educ_Sup);
            ViewBag.Jorn_Comp = new SelectList(db.Jornada_Compl, "Jornada_ID", "Jornada_Nombre", datosUsuario.Jorn_Comp);
            ViewBag.Mov_Red = new SelectList(db.Movilidad, "Mov_ID", "Mov_Nombre", datosUsuario.Mov_Red);

            return View(datosUsuario);
        }

        // POST: DatosUsuario/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "DatosUser_ID,Educ_Sup,Jorn_Comp,Mov_Red,Tipo_trabajo,Profesion,Exper_lab,Habi_des,Resumen_cv,Nacionalidad")] DatosUsuario datosUsuario)
        {
            if (ModelState.IsValid)
            {
                db.Entry(datosUsuario).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Success");
            }
            ViewBag.DatosUser_ID = new SelectList(db.AspNetUsers, "Id", "Email", datosUsuario.DatosUser_ID);
            ViewBag.Nacionalidad = new SelectList(db.Nacionalidad, "Nacionaldad_ID", "Nacionalidad_Nombre", datosUsuario.Nacionalidad);
            ViewBag.Tipo_trabajo = new SelectList(db.TipoTrabajo, "TipoTrabajo_ID", "TipoTrabajo_Nombre", datosUsuario.Tipo_trabajo);
            ViewBag.Educ_Sup = new SelectList(db.Educacion, "Edu_ID", "Edu_Nombre", datosUsuario.Educ_Sup);
            ViewBag.Jorn_Comp = new SelectList(db.Jornada_Compl, "Jornada_ID", "Jornada_Nombre", datosUsuario.Jorn_Comp);
            ViewBag.Mov_Red = new SelectList(db.Movilidad, "Mov_ID", "Mov_Nombre", datosUsuario.Mov_Red);

            return View(datosUsuario);
        }
        public ActionResult Success()
        {
            return View();
        }

        // GET: DatosUsuario/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DatosUsuario datosUsuario = db.DatosUsuario.Find(id);
            if (datosUsuario == null)
            {
                return HttpNotFound();
            }
            return View(datosUsuario);
        }

        // POST: DatosUsuario/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            DatosUsuario datosUsuario = db.DatosUsuario.Find(id);
            db.DatosUsuario.Remove(datosUsuario);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
