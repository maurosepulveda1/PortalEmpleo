﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProyectoBase4.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using IdentitySample.Models;

namespace ProyectoBase4.Controllers
{
    public class DatosEmpresaController : Controller
    {
        private EntitiesPortal db = new EntitiesPortal();

        // GET: DatosEmpresa
        public ActionResult Index()
        {
            var datosEmpresa = db.DatosEmpresa.Include(d => d.AspNetUsers);
            return View(datosEmpresa.ToList());
        }

        // GET: DatosEmpresa/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DatosEmpresa datosEmpresa = db.DatosEmpresa.Find(id);
            if (datosEmpresa == null)
            {
                return HttpNotFound();
            }
            return View(datosEmpresa);
        }

        // GET: DatosEmpresa/Create
        public ActionResult Create()
        {
            ViewBag.DatosEmpresa_ID = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Email;
            return View();
        }

        // POST: DatosEmpresa/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "DatosEmpresa_ID,Rut_Empresa,RazonS_Empresa,Web_Empresa,Rubro_Empresa,Descripcion")] DatosEmpresa datosEmpresa)
        {
            if (ModelState.IsValid)
            {
                db.DatosEmpresa.Add(datosEmpresa);
                datosEmpresa.DatosEmpresa_ID = HttpContext.User.Identity.GetUserId();
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DatosEmpresa_ID = new SelectList(db.AspNetUsers, "Id", "Email", datosEmpresa.DatosEmpresa_ID);
            return View(datosEmpresa);
        }

        // GET: DatosEmpresa/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DatosEmpresa datosEmpresa = db.DatosEmpresa.Find(id);
            if (datosEmpresa == null)
            {
                return HttpNotFound();
            }
            ViewBag.DatosEmpresa_ID = new SelectList(db.AspNetUsers, "Id", "Email", datosEmpresa.DatosEmpresa_ID);
            return View(datosEmpresa);
        }

        // POST: DatosEmpresa/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "DatosEmpresa_ID,Rut_Empresa,RazonS_Empresa,Web_Empresa,Rubro_Empresa,Descripcion")] DatosEmpresa datosEmpresa)
        {
            if (ModelState.IsValid)
            {
                db.Entry(datosEmpresa).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Success");
            }
            ViewBag.DatosEmpresa_ID = new SelectList(db.AspNetUsers, "Id", "Email", datosEmpresa.DatosEmpresa_ID);
            return View(datosEmpresa);
        }
        public ActionResult Success()
        {
            return View();
        }

        // GET: DatosEmpresa/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DatosEmpresa datosEmpresa = db.DatosEmpresa.Find(id);
            if (datosEmpresa == null)
            {
                return HttpNotFound();
            }
            return View(datosEmpresa);
        }

        // POST: DatosEmpresa/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            DatosEmpresa datosEmpresa = db.DatosEmpresa.Find(id);
            db.DatosEmpresa.Remove(datosEmpresa);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
