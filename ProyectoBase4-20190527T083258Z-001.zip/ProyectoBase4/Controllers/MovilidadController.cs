﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProyectoBase4.Models;

namespace ProyectoBase4.Controllers
{
    public class MovilidadController : Controller
    {
        private EntitiesPortal db = new EntitiesPortal();

        // GET: Movilidad
        public ActionResult Index()
        {
            return View(db.Movilidad.ToList());
        }

        // GET: Movilidad/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Movilidad movilidad = db.Movilidad.Find(id);
            if (movilidad == null)
            {
                return HttpNotFound();
            }
            return View(movilidad);
        }

        // GET: Movilidad/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Movilidad/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Mov_ID,Mov_Nombre")] Movilidad movilidad)
        {
            if (ModelState.IsValid)
            {
                db.Movilidad.Add(movilidad);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(movilidad);
        }

        // GET: Movilidad/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Movilidad movilidad = db.Movilidad.Find(id);
            if (movilidad == null)
            {
                return HttpNotFound();
            }
            return View(movilidad);
        }

        // POST: Movilidad/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Mov_ID,Mov_Nombre")] Movilidad movilidad)
        {
            if (ModelState.IsValid)
            {
                db.Entry(movilidad).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(movilidad);
        }

        // GET: Movilidad/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Movilidad movilidad = db.Movilidad.Find(id);
            if (movilidad == null)
            {
                return HttpNotFound();
            }
            return View(movilidad);
        }

        // POST: Movilidad/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Movilidad movilidad = db.Movilidad.Find(id);
            db.Movilidad.Remove(movilidad);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
