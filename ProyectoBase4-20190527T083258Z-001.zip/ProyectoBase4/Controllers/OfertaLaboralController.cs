﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProyectoBase4.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using IdentitySample.Models;
using System.Data.SqlClient;

namespace ProyectoBase4.Controllers
{
    public class OfertaLaboralController : Controller
    {
        private EntitiesPortal db = new EntitiesPortal();
        
        // GET: OfertaLaboral
        public ActionResult Index()
        {
            var ofertaLaboral = db.OfertaLaboral.Include(o => o.Area).Include(o => o.Educacion).Include(o => o.Estado).Include(o => o.Jornada_Compl).Include(o => o.Movilidad).Include(o => o.Subarea).Include(o => o.TipoContrato);
            if (Request.IsAuthenticated) { 
            ViewBag.uservalue = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Rut;
            }
            return View(ofertaLaboral.ToList().OrderByDescending (x => x.Of_FechaIn));
        }

    

        // GET: OfertaLaboral/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OfertaLaboral ofertaLaboral = db.OfertaLaboral.Find(id);
            if (ofertaLaboral == null)
            {
                return HttpNotFound();
            }
            return View(ofertaLaboral);
        }

        // GET: OfertaLaboral/Create
        public ActionResult Create()
        {

            if (Request.IsAuthenticated && User.IsInRole("Adulto Mayor"))
            {
                ViewBag.userrut = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Rut;
                return RedirectToAction("Create", "OfertaPostulante");
            }
            ViewBag.Of_Area = new SelectList(db.Area, "Area_ID", "Area_Nombre");
            ViewBag.Of_Edu = new SelectList(db.Educacion, "Edu_ID", "Edu_Nombre");
            ViewBag.Of_Estado = new SelectList(db.Estado, "Estado_ID", "Estado_Nombre");
            ViewBag.Of_Jornada = new SelectList(db.Jornada_Compl, "Jornada_ID", "Jornada_Nombre");
            ViewBag.Of_Mov = new SelectList(db.Movilidad, "Mov_ID", "Mov_Nombre");
            ViewBag.Of_Subarea = new SelectList(db.Subarea, "Subarea_ID", "Subarea_Nombre");
            ViewBag.Of_TContrato = new SelectList(db.TipoContrato, "TContrato_ID", "TContrato_Nombre");
            

            return View();
        }

       

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Of_ID,OfEmp_ID,Of_Titulo,Of_Puesto,Of_Area,Of_Subarea,Of_Descrp,Of_Lugar,Of_Vacante,Of_FechaIn,Of_FechaFin,Of_Salario,Of_Jornada,Of_Mov,Of_Edu,Of_TContrato,Of_Estado")] OfertaLaboral ofertaLaboral)
        {
            if (ModelState.IsValid)
            {
                db.OfertaLaboral.Add(ofertaLaboral);
                ofertaLaboral.OfEmp_ID = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Rut;
                ofertaLaboral.Of_FechaIn = DateTime.Now;
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Of_Area = new SelectList(db.Area, "Area_ID", "Area_Nombre", ofertaLaboral.Of_Area);
            ViewBag.Of_Edu = new SelectList(db.Educacion, "Edu_ID", "Edu_Nombre", ofertaLaboral.Of_Edu);
            ViewBag.Of_Estado = new SelectList(db.Estado, "Estado_ID", "Estado_Nombre", ofertaLaboral.Of_Estado);
            ViewBag.Of_Jornada = new SelectList(db.Jornada_Compl, "Jornada_ID", "Jornada_Nombre", ofertaLaboral.Of_Jornada);
            ViewBag.Of_Mov = new SelectList(db.Movilidad, "Mov_ID", "Mov_Nombre", ofertaLaboral.Of_Mov);
            ViewBag.Of_Subarea = new SelectList(db.Subarea, "Subarea_ID", "Subarea_Nombre", ofertaLaboral.Of_Subarea);
            ViewBag.Of_TContrato = new SelectList(db.TipoContrato, "TContrato_ID", "TContrato_Nombre", ofertaLaboral.Of_TContrato);
            return View(ofertaLaboral);
        }

        // GET: OfertaLaboral/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OfertaLaboral ofertaLaboral = db.OfertaLaboral.Find(id);
            if (ofertaLaboral == null)
            {
                return HttpNotFound();
            }
            ViewBag.Of_Area = new SelectList(db.Area, "Area_ID", "Area_Nombre", ofertaLaboral.Of_Area);
            ViewBag.Of_Edu = new SelectList(db.Educacion, "Edu_ID", "Edu_Nombre", ofertaLaboral.Of_Edu);
            ViewBag.Of_Estado = new SelectList(db.Estado, "Estado_ID", "Estado_Nombre", ofertaLaboral.Of_Estado);
            ViewBag.Of_Jornada = new SelectList(db.Jornada_Compl, "Jornada_ID", "Jornada_Nombre", ofertaLaboral.Of_Jornada);
            ViewBag.Of_Mov = new SelectList(db.Movilidad, "Mov_ID", "Mov_Nombre", ofertaLaboral.Of_Mov);
            ViewBag.Of_Subarea = new SelectList(db.Subarea, "Subarea_ID", "Subarea_Nombre", ofertaLaboral.Of_Subarea);
            ViewBag.Of_TContrato = new SelectList(db.TipoContrato, "TContrato_ID", "TContrato_Nombre", ofertaLaboral.Of_TContrato);
            return View(ofertaLaboral);
        }

        // POST: OfertaLaboral/Edit/5
   
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Of_ID,OfEmp_ID,Of_Titulo,Of_Puesto,Of_Area,Of_Subarea,Of_Descrp,Of_Lugar,Of_Vacante,Of_FechaIn,Of_FechaFin,Of_Salario,Of_Jornada,Of_Mov,Of_Edu,Of_TContrato,Of_Estado")] OfertaLaboral ofertaLaboral)
        {
            if (ModelState.IsValid)
            {
                db.Entry(ofertaLaboral).State = EntityState.Modified;
                ofertaLaboral.OfEmp_ID = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Rut;
                ofertaLaboral.Of_FechaIn = DateTime.Now;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Of_Area = new SelectList(db.Area, "Area_ID", "Area_Nombre", ofertaLaboral.Of_Area);
            ViewBag.Of_Edu = new SelectList(db.Educacion, "Edu_ID", "Edu_Nombre", ofertaLaboral.Of_Edu);
            ViewBag.Of_Estado = new SelectList(db.Estado, "Estado_ID", "Estado_Nombre", ofertaLaboral.Of_Estado);
            ViewBag.Of_Jornada = new SelectList(db.Jornada_Compl, "Jornada_ID", "Jornada_Nombre", ofertaLaboral.Of_Jornada);
            ViewBag.Of_Mov = new SelectList(db.Movilidad, "Mov_ID", "Mov_Nombre", ofertaLaboral.Of_Mov);
            ViewBag.Of_Subarea = new SelectList(db.Subarea, "Subarea_ID", "Subarea_Nombre", ofertaLaboral.Of_Subarea);
            ViewBag.Of_TContrato = new SelectList(db.TipoContrato, "TContrato_ID", "TContrato_Nombre", ofertaLaboral.Of_TContrato);
            return View(ofertaLaboral);
        }

        // GET: OfertaLaboral/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OfertaLaboral ofertaLaboral = db.OfertaLaboral.Find(id);
            if (ofertaLaboral == null)
            {
                return HttpNotFound();
            }
            return View(ofertaLaboral);
        }

        // POST: OfertaLaboral/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            OfertaLaboral ofertaLaboral = db.OfertaLaboral.Find(id);
            db.OfertaLaboral.Remove(ofertaLaboral);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        
    }
}
