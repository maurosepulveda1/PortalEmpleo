﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProyectoBase4.Models;
using IdentitySample.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;

namespace ProyectoBase4.Controllers
{
    public class OfertaPostulanteController : Controller
    {
        private EntitiesPortal db = new EntitiesPortal();
        
        public ActionResult Index()
        {
           
            if (Request.IsAuthenticated && User.IsInRole("Adulto Mayor"))
            {
                ViewBag.uservalueemail = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Email;
            }
            else
            {
                ViewBag.uservalueemail = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Rut;
            }

            return View(db.OfertaPostulante.ToList().OrderByDescending(x => x.OfPostFecha));
        }
        public ActionResult PostulantesDeOferta(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var of_postulantes = db.OfertaPostulante.Include(o => o.AspNetUsers).Where(o => o.OfPostOf_ID == id);
           
            return View(of_postulantes);
        }
        public ActionResult DetalleUsuario(string id)
        {
            List<AspNetUsers> of2 = db.AspNetUsers.Where(x => x.Id == id).ToList();
            return View(of2);
        }
        
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OfertaPostulante ofertaPostulante = db.OfertaPostulante.Find(id);
            if (ofertaPostulante == null)
            {
                return HttpNotFound();
            }
            return View(ofertaPostulante);
        }

        public ActionResult Detalles1(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OfertaLaboral ofertaLaboral = db.OfertaLaboral.Find(id);
            if (ofertaLaboral == null)
            {
                return HttpNotFound();
            }
            return this.RedirectToAction("Details", "OfertaLaboral", new { id = ofertaLaboral.Of_ID});
        }

        public ActionResult Create()
        {
            ViewBag.OfPostUsr_ID = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Email;
            ViewBag.OfPostOf_ID = new SelectList(db.OfertaLaboral, "Of_ID", "Of_Titulo");

            var userID = User.Identity.GetUserId();
            
            var lista2 = (from u in db.OfertaLaboral
                            from a in db.DatosUsuario
                            where u.Of_Edu == a.Educ_Sup
                            where u.Of_Mov == a.Mov_Red
                            where u.Of_Jornada == a.Jorn_Comp
                            where u.Of_Estado == a.Tipo_trabajo
                            where a.DatosUser_ID == userID
                            orderby u.Of_FechaIn descending
                            select u);
            ViewBag.ListaCondicion = lista2.ToList();
            return View();
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "OfPost_ID,OfPostOf_ID,OfPostUsr_ID,OfPostFecha,OfPost_Estado")] OfertaPostulante ofertaPostulante)
        {
            if (ModelState.IsValid)
            {
                db.OfertaPostulante.Add(ofertaPostulante);
                var Datetimenow = DateTime.Now;
                ofertaPostulante.OfPostFecha = new DateTime(Datetimenow.Year, Datetimenow.Month, Datetimenow.Day, Datetimenow.Hour, Datetimenow.Minute, 0);
                ofertaPostulante.OfPostUsr_ID = HttpContext.User.Identity.GetUserId();
                db.SaveChanges();
                return RedirectToAction("Success");
            }

            ViewBag.OfPostUsr_ID = new SelectList(db.AspNetUsers, "Id", "Email", ofertaPostulante.OfPostUsr_ID);
            ViewBag.OfPostOf_ID = new SelectList(db.OfertaLaboral, "Of_ID", "Of_Titulo", ofertaPostulante.OfPostOf_ID);
            ViewBag.OfPost_Estado = new SelectList(db.EstadoPost, "EstadoPost_ID", "EstadoPost_Nombre", ofertaPostulante.OfPost_Estado);
            return View(ofertaPostulante);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OfertaPostulante ofertaPostulante = db.OfertaPostulante.Find(id);
            if (ofertaPostulante == null)
            {
                return HttpNotFound();
            }
            ViewBag.OfPostUsr_ID = new SelectList(db.AspNetUsers, "Id", "Email", ofertaPostulante.OfPostUsr_ID);
            ViewBag.OfPostOf_ID = new SelectList(db.OfertaLaboral, "Of_ID", "Of_Titulo", ofertaPostulante.OfPostOf_ID);
            ViewBag.OfPost_Estado = new SelectList(db.EstadoPost, "EstadoPost_ID", "EstadoPost_Nombre", ofertaPostulante.OfPost_Estado);
            return View(ofertaPostulante);
        }

        public ActionResult EditarEstado(int? id)
        {
            if(id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OfertaPostulante ofertaPostulante = db.OfertaPostulante.Find(id);
            if (ofertaPostulante == null)
            {
                return HttpNotFound();
            }
            return View();
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "OfPost_ID,OfPostOf_ID,OfPostUsr_ID,OfPostFecha,OfPost_Estado")] OfertaPostulante ofertaPostulante)
        {
            if (ModelState.IsValid)
            {
                db.Entry(ofertaPostulante).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Success2");
            }
            ViewBag.OfPostUsr_ID = new SelectList(db.AspNetUsers, "Id", "Email", ofertaPostulante.OfPostUsr_ID);
            ViewBag.OfPostOf_ID = new SelectList(db.OfertaLaboral, "Of_ID", "Of_Titulo", ofertaPostulante.OfPostOf_ID);
            ViewBag.OfPost_Estado = new SelectList(db.EstadoPost, "EstadoPost_ID", "EstadoPost_Nombre", ofertaPostulante.OfPost_Estado);
            return View(ofertaPostulante);
        }
        
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OfertaPostulante ofertaPostulante = db.OfertaPostulante.Find(id);
            if (ofertaPostulante == null)
            {
                return HttpNotFound();
            }
            return View(ofertaPostulante);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            OfertaPostulante ofertaPostulante = db.OfertaPostulante.Find(id);
            db.OfertaPostulante.Remove(ofertaPostulante);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Success()
        {
            return View();
        }
        public ActionResult Success2()
        {
            return View();
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
