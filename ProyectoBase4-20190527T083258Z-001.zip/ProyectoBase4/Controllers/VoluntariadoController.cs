﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using IdentitySample.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using ProyectoBase4.Models;

namespace ProyectoBase4.Controllers
{
    public class VoluntariadoController : Controller
    {
        private EntitiesPortal db = new EntitiesPortal();

        // GET: Voluntariado
        public ActionResult Index()
        {
            var voluntariado = db.Voluntariado.Include(v => v.Area).Include(v => v.Educacion).Include(v => v.Estado).Include(v => v.Jornada_Compl).Include(v => v.Movilidad).Include(v => v.Subarea).Include(v => v.TipoContrato);
            if (Request.IsAuthenticated)
            {
                ViewBag.uservalue = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Rut;
            }
            return View(voluntariado.ToList().OrderByDescending(x => x.Vol_FechaIn));
        }

        // GET: Voluntariado/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Voluntariado voluntariado = db.Voluntariado.Find(id);
            if (voluntariado == null)
            {
                return HttpNotFound();
            }
            return View(voluntariado);
        }

        // GET: Voluntariado/Create
        public ActionResult Create()
        {
            if(Request.IsAuthenticated && User.IsInRole("Adulto Mayor"))
            {
                ViewBag.userrut = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Rut;
                return RedirectToAction("Create", "VoluntariadoPostulante");

            }
            ViewBag.Vol_Area = new SelectList(db.Area, "Area_ID", "Area_Nombre");
            ViewBag.Vol_Edu = new SelectList(db.Educacion, "Edu_ID", "Edu_Nombre");
            ViewBag.Vol_Estado = new SelectList(db.Estado, "Estado_ID", "Estado_Nombre");
            ViewBag.Vol_Jornada = new SelectList(db.Jornada_Compl, "Jornada_ID", "Jornada_Nombre");
            ViewBag.Vol_Mov = new SelectList(db.Movilidad, "Mov_ID", "Mov_Nombre");
            ViewBag.Vol_Subarea = new SelectList(db.Subarea, "Subarea_ID", "Subarea_Nombre");
            ViewBag.Vol_TContrato = new SelectList(db.TipoContrato, "TContrato_ID", "TContrato_Nombre");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Vol_ID,Vol_Autor_ID,Vol_Titulo,Vol_Puesto,Vol_Area,Vol_Subarea,Vol_Descp,Vol_Lugar,Vol_Vac,Vol_Vac_Disp,Vol_FechaIn,Vol_FechaFin,Vol_Jornada,Vol_Mov,Vol_Edu,Vol_TContrato,Vol_Estado")] Voluntariado voluntariado)
        {
            if (ModelState.IsValid)
            {
                db.Voluntariado.Add(voluntariado);
                voluntariado.Vol_Autor_ID = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Rut;
                voluntariado.Vol_FechaIn = DateTime.Now;
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Vol_Area = new SelectList(db.Area, "Area_ID", "Area_Nombre", voluntariado.Vol_Area);
            ViewBag.Vol_Edu = new SelectList(db.Educacion, "Edu_ID", "Edu_Nombre", voluntariado.Vol_Edu);
            ViewBag.Vol_Estado = new SelectList(db.Estado, "Estado_ID", "Estado_Nombre", voluntariado.Vol_Estado);
            ViewBag.Vol_Jornada = new SelectList(db.Jornada_Compl, "Jornada_ID", "Jornada_Nombre", voluntariado.Vol_Jornada);
            ViewBag.Vol_Mov = new SelectList(db.Movilidad, "Mov_ID", "Mov_Nombre", voluntariado.Vol_Mov);
            ViewBag.Vol_Subarea = new SelectList(db.Subarea, "Subarea_ID", "Subarea_Nombre", voluntariado.Vol_Subarea);
            ViewBag.Vol_TContrato = new SelectList(db.TipoContrato, "TContrato_ID", "TContrato_Nombre", voluntariado.Vol_TContrato);
            return View(voluntariado);
        }

        // GET: Voluntariado/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Voluntariado voluntariado = db.Voluntariado.Find(id);
            if (voluntariado == null)
            {
                return HttpNotFound();
            }
            ViewBag.Of_Area = new SelectList(db.Area, "Area_ID", "Area_Nombre", voluntariado.Vol_Area);
            ViewBag.Vol_Edu = new SelectList(db.Educacion, "Edu_ID", "Edu_Nombre", voluntariado.Vol_Edu);
            ViewBag.Vol_Estado = new SelectList(db.Estado, "Estado_ID", "Estado_Nombre", voluntariado.Vol_Estado);
            ViewBag.Vol_Jornada = new SelectList(db.Jornada_Compl, "Jornada_ID", "Jornada_Nombre", voluntariado.Vol_Jornada);
            ViewBag.Vol_Mov = new SelectList(db.Movilidad, "Mov_ID", "Mov_Nombre", voluntariado.Vol_Mov);
            ViewBag.Vol_Subarea = new SelectList(db.Subarea, "Subarea_ID", "Subarea_Nombre", voluntariado.Vol_Subarea);
            ViewBag.Vol_TContrato = new SelectList(db.TipoContrato, "TContrato_ID", "TContrato_Nombre", voluntariado.Vol_TContrato);
            return View(voluntariado);
        }

        // POST: Voluntariado/Edit/5
       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Vol_ID,Vol_Autor_ID,Vol_Titulo,Vol_Puesto,Vol_Subarea,Vol_Descp,Vol_Lugar,Vol_Vac,Vol_Vac_Disp,Vol_FechaIn,Vol_FechaFin,Vol_Jornada,Vol_Mov,Vol_Edu,Vol_TContrato,Vol_Estado")] Voluntariado voluntariado)
        {
            if (ModelState.IsValid)
            {
                db.Entry(voluntariado).State = EntityState.Modified;
                voluntariado.Vol_Autor_ID = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Rut;
                voluntariado.Vol_FechaFin = DateTime.Now;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Vol_Edu = new SelectList(db.Educacion, "Edu_ID", "Edu_Nombre", voluntariado.Vol_Edu);
            ViewBag.Vol_Estado = new SelectList(db.Estado, "Estado_ID", "Estado_Nombre", voluntariado.Vol_Estado);
            ViewBag.Vol_Jornada = new SelectList(db.Jornada_Compl, "Jornada_ID", "Jornada_Nombre", voluntariado.Vol_Jornada);
            ViewBag.Vol_Mov = new SelectList(db.Movilidad, "Mov_ID", "Mov_Nombre", voluntariado.Vol_Mov);
            ViewBag.Vol_Subarea = new SelectList(db.Subarea, "Subarea_ID", "Subarea_Nombre", voluntariado.Vol_Subarea);
            ViewBag.Vol_TContrato = new SelectList(db.TipoContrato, "TContrato_ID", "TContrato_Nombre", voluntariado.Vol_TContrato);
            return View(voluntariado);
        }

        // GET: Voluntariado/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Voluntariado voluntariado = db.Voluntariado.Find(id);
            if (voluntariado == null)
            {
                return HttpNotFound();
            }
            return View(voluntariado);
        }

        // POST: Voluntariado/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Voluntariado voluntariado = db.Voluntariado.Find(id);
            db.Voluntariado.Remove(voluntariado);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
