﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProyectoBase4.Models;

namespace ProyectoBase4.Controllers
{
    public class TipoContratoController : Controller
    {
        private EntitiesPortal db = new EntitiesPortal();

        // GET: TipoContrato
        public ActionResult Index()
        {
            return View(db.TipoContrato.ToList());
        }

        // GET: TipoContrato/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TipoContrato tipoContrato = db.TipoContrato.Find(id);
            if (tipoContrato == null)
            {
                return HttpNotFound();
            }
            return View(tipoContrato);
        }

        // GET: TipoContrato/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: TipoContrato/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "TContrato_ID,TContrato_Nombre")] TipoContrato tipoContrato)
        {
            if (ModelState.IsValid)
            {
                db.TipoContrato.Add(tipoContrato);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tipoContrato);
        }

        // GET: TipoContrato/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TipoContrato tipoContrato = db.TipoContrato.Find(id);
            if (tipoContrato == null)
            {
                return HttpNotFound();
            }
            return View(tipoContrato);
        }

        // POST: TipoContrato/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "TContrato_ID,TContrato_Nombre")] TipoContrato tipoContrato)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tipoContrato).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tipoContrato);
        }

        // GET: TipoContrato/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TipoContrato tipoContrato = db.TipoContrato.Find(id);
            if (tipoContrato == null)
            {
                return HttpNotFound();
            }
            return View(tipoContrato);
        }

        // POST: TipoContrato/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            TipoContrato tipoContrato = db.TipoContrato.Find(id);
            db.TipoContrato.Remove(tipoContrato);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
