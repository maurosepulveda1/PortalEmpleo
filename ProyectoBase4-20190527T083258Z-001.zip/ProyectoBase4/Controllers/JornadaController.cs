﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProyectoBase4.Models;

namespace ProyectoBase4.Controllers
{
    public class JornadaController : Controller
    {
        private EntitiesPortal db = new EntitiesPortal();

        // GET: Jornada
        public ActionResult Index()
        {
            return View(db.Jornada_Compl.ToList());
        }

        // GET: Jornada/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Jornada_Compl jornada_Compl = db.Jornada_Compl.Find(id);
            if (jornada_Compl == null)
            {
                return HttpNotFound();
            }
            return View(jornada_Compl);
        }

        // GET: Jornada/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Jornada/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Jornada_ID,Jornada_Nombre")] Jornada_Compl jornada_Compl)
        {
            if (ModelState.IsValid)
            {
                db.Jornada_Compl.Add(jornada_Compl);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(jornada_Compl);
        }

        // GET: Jornada/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Jornada_Compl jornada_Compl = db.Jornada_Compl.Find(id);
            if (jornada_Compl == null)
            {
                return HttpNotFound();
            }
            return View(jornada_Compl);
        }

        // POST: Jornada/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Jornada_ID,Jornada_Nombre")] Jornada_Compl jornada_Compl)
        {
            if (ModelState.IsValid)
            {
                db.Entry(jornada_Compl).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(jornada_Compl);
        }

        // GET: Jornada/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Jornada_Compl jornada_Compl = db.Jornada_Compl.Find(id);
            if (jornada_Compl == null)
            {
                return HttpNotFound();
            }
            return View(jornada_Compl);
        }

        // POST: Jornada/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Jornada_Compl jornada_Compl = db.Jornada_Compl.Find(id);
            db.Jornada_Compl.Remove(jornada_Compl);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
