﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProyectoBase4.Models;

namespace ProyectoBase4.Controllers
{
    public class SubareaController : Controller
    {
        private EntitiesPortal db = new EntitiesPortal();

        // GET: Subarea
        public ActionResult Index()
        {
            var subarea = db.Subarea.Include(s => s.Area);
            return View(subarea.ToList());
        }

        // GET: Subarea/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Subarea subarea = db.Subarea.Find(id);
            if (subarea == null)
            {
                return HttpNotFound();
            }
            return View(subarea);
        }

        // GET: Subarea/Create
        public ActionResult Create()
        {
            ViewBag.Subarea_Area_ID = new SelectList(db.Area, "Area_ID", "Area_Nombre");
            return View();
        }

        // POST: Subarea/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Subarea_ID,Subarea_Nombre,Subarea_Area_ID")] Subarea subarea)
        {
            if (ModelState.IsValid)
            {
                db.Subarea.Add(subarea);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Subarea_Area_ID = new SelectList(db.Area, "Area_ID", "Area_Nombre", subarea.Subarea_Area_ID);
            return View(subarea);
        }

        // GET: Subarea/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Subarea subarea = db.Subarea.Find(id);
            if (subarea == null)
            {
                return HttpNotFound();
            }
            ViewBag.Subarea_Area_ID = new SelectList(db.Area, "Area_ID", "Area_Nombre", subarea.Subarea_Area_ID);
            return View(subarea);
        }

        // POST: Subarea/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Subarea_ID,Subarea_Nombre,Subarea_Area_ID")] Subarea subarea)
        {
            if (ModelState.IsValid)
            {
                db.Entry(subarea).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Subarea_Area_ID = new SelectList(db.Area, "Area_ID", "Area_Nombre", subarea.Subarea_Area_ID);
            return View(subarea);
        }

        // GET: Subarea/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Subarea subarea = db.Subarea.Find(id);
            if (subarea == null)
            {
                return HttpNotFound();
            }
            return View(subarea);
        }

        // POST: Subarea/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Subarea subarea = db.Subarea.Find(id);
            db.Subarea.Remove(subarea);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
