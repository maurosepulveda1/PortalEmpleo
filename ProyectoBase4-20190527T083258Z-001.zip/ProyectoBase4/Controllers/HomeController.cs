﻿using IdentitySample.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using ProyectoBase4.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IdentitySample.Controllers
{
    public class HomeController : Controller
    {
        EntitiesPortal db = new EntitiesPortal();

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Contacto()
        {
            return View();
        }
        public ActionResult PreguntasFrecuentes()
        {
            return View();
        }
        public ActionResult Participantes()
        {
            return View();
        }
        public ActionResult GuiaUso()
        {
            return View();
        }

        public ActionResult EmpresasParticipantes()
        {

            using (var context = new ApplicationDbContext())
            {

                var Empresa = context.Users
                                   .Where(u => u.Roles.Any(r => r.RoleId == "71f99c53-7336-493b-b92c-ffd429f8e467")).OrderBy(x => x.PhoneNumber)
                                   .ToList();
                ViewBag.EM = Empresa;

                return View(Empresa);
            }
            
        }

        public ActionResult Edit()
        {
            return this.RedirectToAction("Edit", "UsersAdmin", new { id = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Id});
        }
        public ActionResult EditarDatoEmpresa()
        {
            return this.RedirectToAction("Edit", "DatosEmpresa", new { id = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Id });
        }

        public ActionResult EditarDatoUsuario()
        {
            return this.RedirectToAction("Edit", "DatosUsuario", new { id = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindByName(User.Identity.Name).Id });
        }


        public ActionResult Datos()
        {
            var infoempresa = (from dato in db.DatosEmpresa select dato).ToList().Count();
            ViewBag.DatoEmpresa = infoempresa;

            var infoadulto = (from dato in db.DatosUsuario select dato).ToList().Count();
            ViewBag.DatoAdulto = infoadulto;

            var oferta = (from dato in db.OfertaLaboral select dato).ToList().Count();
            ViewBag.DatoOferta = oferta;

            var ofertapost = (from dato in db.OfertaPostulante select dato).ToList().Count();
            ViewBag.DatoOfPost = ofertapost;

            var volpost = (from dato in db.VoluntariadoPostulante select dato).ToList().Count();
            ViewBag.DatoVolPost = volpost;

            var oferta2 = (from dato in db.Voluntariado select dato).ToList().Count();
            ViewBag.DatoVol = oferta2;


            using (var context = new ApplicationDbContext())
            {
                var AdultoMayor = context.Users
                                    .Where(u => u.Roles.Any(r => r.RoleId == "6f3ed187-b5e8-470b-b905-8dd162542299"))
                                    .ToList().Count();
                ViewBag.AM = AdultoMayor;

                var Empresa = context.Users
                                   .Where(u => u.Roles.Any(r => r.RoleId == "71f99c53-7336-493b-b92c-ffd429f8e467"))
                                   .ToList().Count();
                ViewBag.EM = Empresa;

                var Voluntariado = context.Users
                                   .Where(u => u.Roles.Any(r => r.RoleId == "a765cb5f-137f-4fba-a1c8-ab905585d612"))
                                   .ToList().Count();
                ViewBag.VOL = Voluntariado;

                var Admin = context.Users
                                   .Where(u => u.Roles.Any(r => r.RoleId == "ce525218-b4d6-47c3-9465-fa3dc9d3648f"))
                                   .ToList().Count();
                ViewBag.ADM = Admin;

                var Total = context.Users
                                   
                                   .ToList().Count();
                ViewBag.TO = Total;
            }
            
            return View();
        }
       
        

    }
}
